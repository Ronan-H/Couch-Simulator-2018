How to run the game:

- Try double clicking the jar file (if default program to open is not java, right click -> open with -> find java)
- If that doesn't work, try executing the appropriate shell script
